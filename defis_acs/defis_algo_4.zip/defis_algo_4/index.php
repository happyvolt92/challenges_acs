<?php

$a = (int)readline('1er valeur : ');
$b = (int)readline('2eme valeur : ');
$c = (int)readline('3eme valeur : ');
$d = (int)readline('4eme valeur : ');
$e = (int)readline('5eme valeur : ');
$f = (int)readline('6eme valeur : ');
$g = (int)readline('7eme valeur : ');
$h = (int)readline('8eme valeur : ');
$i = (int)readline('9eme valeur : ');
$j = (int)readline('10eme valeur : ');
$k = (int)readline('11eme valeur : ');
$l = (int)readline('12eme valeur : ');
$m = (int)readline('13eme valeur : ');
$n = (int)readline('14eme valeur : ');
$o = (int)readline('15eme valeur : ');
$p = (int)readline('16eme valeur : ');
$q = (int)readline('17eme valeur : ');
$r = (int)readline('18eme valeur : ');
$s = (int)readline('19eme valeur : ');
$t = (int)readline('20eme valeur : ');


echo "La plus grande valeur est : ".(max(array($a, $b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t))). "." . "\n";

?>