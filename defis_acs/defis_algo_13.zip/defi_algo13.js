const form = document.querySelector('form');
const chaine = document.getElementById('chaine');
const caractere = document.getElementById('caractere');
const p = document.querySelector('p');

function Purge($x, $y){
    let after = "";
    if($y.length == 1){
        for(i = 0; i < $x.length; i++){
            if($y != $x[i]){
                after += $x[i];
            }
        }
        p.innerHTML = after;
    }
    else{
        p.innerHTML = "Un seul caractère attendu";
    }
    
}

form.addEventListener('submit', function(e){
    e.preventDefault();
    let chaineVal = chaine.value;
    let caractereVal = caractere.value;
    Purge(chaineVal, caractereVal);
})

