var x = 0;
$('.form1').on('submit', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'GET',
        data: $(this).serialize(),
        success: function () {
            if ($('.form1')[0].checkValidity()) {
                if ($('li').length < 17) {
                    $('ul').append("<li class='md:pr-8 md:pl-8 md:pt-8 pr-2 pl-2 pt-2'>" + $('#name').val() + " <span>" + $('#note').val() + "</span><button class='ml-2 mr-2  p-2 mt-4 self-center md:self-start md:p-4 bg-blue-600 text-white rounded-lg text-lg focus:outline-none buttedit'>Edit</button><button class='buttdel ml-2 mr-2  p-2 mt-4 self-center md:self-start md:p-4 bg-blue-600 text-white rounded-lg text-lg focus:outline-none'>Delete</button></li>");


                    $('.buttedit').bind('click', function () {
                        let change = $(this).prev();

                        $('.edit').show();
                        $('.edit form').bind('submit', function (e) {
                            e.preventDefault();
                            $.ajax({
                                type: 'GET',
                                success: function () {
                                    change.html($('.edit input').val());
                                    setTimeout(() => {
                                        $('.edit').hide();
                                    }, 200);
                                }
                            })
                        })
                    });
                    $('.tri').bind('click', function () {
                        var list = $('ul').children('li');
                        var tri = Array.prototype.sort.bind(list);

                        tri(function (a, b) {
                            var aText = a.innerHTML;
                            var bText = b.innerHTML;

                            if (aText < bText) {
                                return -1;
                            } else {
                                return 1;
                            };

                        });
                        $('ul').append(list);
                    });

                    $('.best').bind('click', function () {
                        var list = $('ul').children('li');
                        var tri = Array.prototype.sort.bind(list);

                        tri(function (a, b) {
                            var aText = parseInt(a.children[0].innerHTML * 10) / 10;
                            
                            var bText = parseInt(b.children[0].innerHTML * 10) / 10;

                            if (aText > bText) {
                                return -1;
                            } else {
                                return 1;
                            };

                        });
                        $('ul').append(list);
                    });


                    $('.buttdel').bind('click', function () {
                        var del = $(this).parent();
                        del.remove();
                        $('.alert').html("");
                        if ($('li').length < 2) {
                            $('.moyenne').remove();
                        }


                    });
                    if ($('li').length > 1) {
                        if (!$('.moyenne').length) {
                            $('body').append("<button class='moyenne md:w-1/5 w-2/5 p-2 mt-4 self-center  md:p-4 bg-blue-600 text-white rounded-lg text-lg focus:outline-none' onclick='Click();'>Calculer la moyenne</button>");
                        }
                    }
                } else {
                    $('.alert').html("Nombre maximum d'élèves atteint, déso pas déso");
                }
            }
        }
    })
});



function Click() {

    $.ajax({
        type: 'GET',
        data: parseInt($('li span')),
        success: function () {
            x = 0;
            // for (a = 0; a < 17; a++) {
            //     if($('.eleve' + a).length){
            //     x += parseInt($('.eleve' + a).html() * 10) / 10;
            //     console.log(x);
            // }};
            $('li span').each(function () {
                x += parseInt($(this).html() * 10) / 10;
            });

            moyenne = x / $('li span').length;

            $('.text1').html("La moyenne de la classe est de " + moyenne + "/20");
            if (moyenne < 8) {
                $('.text2').html("Peut mieux faire tout de même !");
            } else if (moyenne < 10) {
                $('.text2').html("En progrès, enfin je crois...");
            } else if (moyenne == 10) {
                $('.text2').html("Ouf, ça passe !");
            } else if (moyenne < 18) {
                $('.text2').html("Yep, de mieux en mieux");
            } else if (moyenne < 20) {
                $('.text2').html("Incredible !!");
            } else {
                $('.text2').html("Fieffés tricheurs !!");
            }
        }
    })
};

