# Exercice 1
maVariable = input("Veuillez saisir un nombre :")

monEntier = int(maVariable)
if (monEntier < 20):
    print("Vous avez saisi un nombre inférieur 20")
elif (monEntier == 20):
    print("Ce nombre est égal à 20")
else:
    print("Vous avez saisi un nombre supérieur à 20")


# Excercice 2
from math import pi

maVariable =int(input("Veuillez saisir un rayon :"))

def CircleArea(maVariable):
    return pi*(maVariable*maVariable)
print(str(CircleArea(maVariable)))
