<?php 

function reprographie($a)
{
    if ($a <= 10) {
        $p = 0.1 * $a;
    }
    elseif ($a <= 30) {
        $p = 0.1 + 0.09 * $a;
    }
    else {
        $p = 0.4 + 0.08 * $a;
    }
    echo $p."€\n";
}
reprographie(50);
?>