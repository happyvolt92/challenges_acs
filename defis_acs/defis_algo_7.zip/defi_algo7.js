var tableau1 = [1, 1, 1, 1, 1, 500, 4436];
var tableau2 = [2, 2, 55555555555, 1000, 4444];
var length1 = tableau1.length;
var length2 = tableau2.length;
var y = 0;
for(let i = 0; i < length1;  i++){
    for(let o = 0; o < length2; o++){
       
        var x = tableau1[i] * tableau2[o];
        y += x; 
        
        
        
    }
}
console.log(y);
