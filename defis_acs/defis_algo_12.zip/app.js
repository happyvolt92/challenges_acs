function longueur(array){
    let i = 0;
    while(array[i]){
        i++;
    }
    return i;
    
}


const size = document.getElementById('size');
const exo_1 = document.getElementById('exo_1');
size.addEventListener('submit', function(e){
    e.preventDefault();
    let input_size = document.getElementById('input_size').value;
    console.log(input_size.split(''));
    exo_1.innerHTML = longueur(input_size.split(''));
});

const addition = document.getElementById('addition');
const exo_2 = document.getElementById('exo_2');
addition.addEventListener('submit', function(e){
    e.preventDefault();
    somme = 0;
    for(i = 1; i < 6; i++){
        somme += parseInt(document.getElementById('input_addition' + i).value);
    }
    exo_2.innerHTML = somme;
});

const voyelle = document.getElementById('voyelle');
const exo_3 = document.getElementById('exo_3');
voyelle.addEventListener('submit', function(e){
    e.preventDefault();
    let input_voyelle = document.getElementById('input_voyelle').value;
    let split = input_voyelle.toLowerCase() ;
    let compte = 0;
    for(i = 0; i < split.length; i++){
        if(split[i] == "a" || split[i] == "e" || split[i] == "i" || split[i] == "o" || split[i] == "u" || split[i] == "y"){
            compte++;
        }
    }
    exo_3.innerHTML = compte;
})