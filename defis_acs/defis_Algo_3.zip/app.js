var input = document.querySelector("input")

function table(){
    var a = input.value;
    document.querySelector("p").textContent = "";
    for (let i = 0; i < 11; i++){ 
        document.querySelector("p").textContent +=  a + " * " + i + " = " + a * i + " ";
    }
}