$('form').bind('submit', function (e) {
    e.preventDefault();
    var letter = $('input').val().split("");
    console.log(letter);
    const isAlpha = code => (code >= 65 && code <= 90) || (code >= 97 && code <=
        122);
    const isLast = code => code === 90 || code === 122;
    const nextLetterString = letter => {
        return letter.reduce((acc, val) => {
            const code = val.charCodeAt(0);
            if (!isAlpha(code)) {
                return acc + val;
            };
            if (isLast(code)) {
                return acc + String.fromCharCode(code - 25);
            };
            return acc + String.fromCharCode(code + 1);
        }, '');
    };
    console.log(nextLetterString(letter));
    $('p').html(nextLetterString(letter));
})