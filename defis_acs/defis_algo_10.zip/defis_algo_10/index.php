<?php

$alpha ="abcdefghijklmnopqrstuvwxyz";
$key = readline("Entrez la clé : ");


if(strlen($key) === 26){
    $secret = readline("Entrez votre phrase : ");
    if(preg_match("/^[a-z0-9 -]+$/i", $secret)){
        echo "\n ok \n ";
    }
    else{
        echo 'erreur';
    }
for($i=0; $i < strlen($secret); $i++){
    if($secret[$i] == " "){
        print_r(" ");
    }
    else{
        $pos = strpos($alpha, $secret[$i]);
        echo $key[$pos];
    }
  
}}
elseif(strlen($key) > 26){
    echo "trop de caractères";
}

else{
    echo "il manque de des caractères";
}

