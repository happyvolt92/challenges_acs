echo -n "Donnez moi votre âge et votre genre (F ou M) s'il vous plaît : " 
read a b
 if [ $a -gt 17 -a $a -lt 36 -a $b = F  -o  $a -gt 19 -a $b = M ]
 then echo "Vous êtes imposables"
 else
   echo "Vous n'êtes pas imposable"
fi