<?php
$client = array('age' => readline("Âge : "), 'exp' => readline("Années d'expérience : "), 'accidents' => readline("Nombre d'accidents survenus : "), 'anciennete' => readline("Ancienneté : "));
// echo json_encode($client)."\n";

foreach ($client as $key => $value) {
    if(!is_numeric($client[$key]) || $client[$key] < 0){
        echo "impossible \n";
        die;
    }
}

if($client['age'] < 18 || $client['accidents'] > 2 || ($client['exp'] < 2 || $client['age'] < 25) && $client['accidents'] > 1 || $client['exp'] < 2 && $client['age'] < 25 && $client['accidents'] > 0){
    echo "nous n'avons pas de tarifs correspondant à votre cas.";
    die;
}
else{
// elseif ($client['anciennete'] < 5) {
//    if($client['age'] >= 25 && $client['exp'] >= 2 && $client['accidents'] == 0){
//     echo "vous êtes elligible au tarif vert";
//    }
//    elseif($client['age'] >= 25 && $client['exp'] >= 2 && $client['accidents'] == 1 || ($client['exp'] < 2 || $client['age'] < 25) && $client['accidents'] == 0 || $client['exp'] < 2 && $client['age'] < 25 && $client['accidents'] == 0){
//        echo "vous êtes elligible au tarif orange";
//    }
//    else{
//        echo "vous êtes elligible au tarif rouge";
//    }
// }
// else{
//     if($client['age'] >= 25 && $client['exp'] >= 2 && $client['accidents'] == 0){
//     echo "vous êtes elligible au tarif bleu";
//    }
//    elseif($client['age'] >= 25 && $client['exp'] >= 2 && $client['accidents'] == 1 || ($client['exp'] < 2 || $client['age'] < 25) && $client['accidents'] == 1 || $client['exp'] < 2 && $client['age'] < 25 && $client['accidents'] == 0){
//        echo "vous êtes elligible au tarif vert !";
//    }
//    else{
//         echo "vous êtes elligible au tarif orange";
//    }
// }

// Version opti : 

$points = 0;
if($client['age'] >= 25){
    $points += 50;
}
else{
    $points += 25;
}
if($client['exp'] > 2){
    $points += 25;
}
if($client['anciennete'] >= 5){
    $points += 25;
}
$points += - $client['accidents'] * 25;

switch ($points) {
    case 25:
        echo "vous êtes elligible au tarif rouge";
        break;
    case 50:
        echo "vous êtes elligible au tarif orange";
        break;
    case 75:
        echo "vous êtes elligible au tarif vert";
        break;
    default:
        echo "vous êtes elligible au tarif bleu";
        break;
}
}